package com.sanz.epep.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.sanz.epep.data.local.PrefsManager

object OverlayManager {

    private var lockOverlay: LockOverlayView? = null
    private var panicOverlay: PanicOverlayView? = null
    private var messageOverlay: MessageOverlayView? = null
    private var statusBarBlock: View? = null

    // === LOCK OVERLAY ===

    fun showLock(context: Context) {
        if (lockOverlay != null) return
        PrefsManager.isLockActive = true

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lockOverlay = LockOverlayView(context)
        lockOverlay?.onUnlocked = { hideLock(context) }

        try {
            wm.addView(lockOverlay, createFullscreenParams(focusable = true))
            showStatusBarBlock(context)
        } catch (e: Exception) {
            e.printStackTrace()
            lockOverlay = null
        }
    }

    fun hideLock(context: Context) {
        PrefsManager.isLockActive = false
        lockOverlay?.let {
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(it)
            } catch (_: Exception) {}
            lockOverlay = null
        }
        if (panicOverlay == null) hideStatusBarBlock(context)
    }

    fun isLocked(): Boolean = lockOverlay != null

    // === PANIC OVERLAY ===

    fun showPanic(context: Context, phone: String = "") {
        if (panicOverlay != null) return
        PrefsManager.isPanicActive = true

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        panicOverlay = PanicOverlayView(context, phone)

        try {
            wm.addView(panicOverlay, createFullscreenParams(focusable = false))
            showStatusBarBlock(context)
        } catch (e: Exception) {
            e.printStackTrace()
            panicOverlay = null
        }
    }

    fun hidePanic(context: Context) {
        PrefsManager.isPanicActive = false
        panicOverlay?.let {
            it.stopAlarm()
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(it)
            } catch (_: Exception) {}
            panicOverlay = null
        }
        if (lockOverlay == null) hideStatusBarBlock(context)
    }

    fun isPanicActive(): Boolean = panicOverlay != null

    // === MESSAGE OVERLAY ===

    fun showMessage(context: Context, message: String, durationMs: Long = 10000L) {
        hideMessage(context)
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 100
        }
        messageOverlay = MessageOverlayView(context, message)
        try {
            wm.addView(messageOverlay, params)
            messageOverlay?.postDelayed({ hideMessage(context) }, durationMs)
        } catch (e: Exception) {
            e.printStackTrace()
            messageOverlay = null
        }
    }

    fun hideMessage(context: Context) {
        messageOverlay?.let {
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(it)
            } catch (_: Exception) {}
            messageOverlay = null
        }
    }

    // === STATUS BAR BLOCK ===

    private fun showStatusBarBlock(context: Context) {
        if (statusBarBlock != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val blockHeight = (80 * context.resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            blockHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        statusBarBlock = View(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setOnTouchListener { _, _ -> true }
        }
        try {
            wm.addView(statusBarBlock, params)
        } catch (e: Exception) {
            e.printStackTrace()
            statusBarBlock = null
        }
    }

    private fun hideStatusBarBlock(context: Context) {
        statusBarBlock?.let {
            try {
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(it)
            } catch (_: Exception) {}
            statusBarBlock = null
        }
    }

    // === RESTORE SETELAH REBOOT ===

    fun restoreAfterBoot(context: Context) {
        if (PrefsManager.isPanicActive) showPanic(context)
        if (PrefsManager.isLockActive) showLock(context)
    }

    // === HELPER ===

    private fun createFullscreenParams(focusable: Boolean): WindowManager.LayoutParams {
        val flags = if (focusable) {
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        }
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
    }

    fun removeAll(context: Context) {
        hideLock(context)
        hidePanic(context)
        hideMessage(context)
        hideStatusBarBlock(context)
    }
}
