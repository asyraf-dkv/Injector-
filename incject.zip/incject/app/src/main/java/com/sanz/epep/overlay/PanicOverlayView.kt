package com.sanz.epep.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class PanicOverlayView(
    context: Context,
    private val parentPhone: String = ""
) : FrameLayout(context) {

    private var toneGenerator: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isAlarmPlaying = false

    init {
        setBackgroundColor(Color.parseColor("#FF0000"))
        isFocusable = true
        isClickable = true

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60, 0, 60, 0)
        }

        // Warning icon
        val icon = TextView(context).apply {
            text = "⚠️"
            textSize = 80f
            gravity = Gravity.CENTER
        }
        container.addView(icon, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 40 })

        // Title
        val title = TextView(context).apply {
            text = "AH AH HAPE MU KENAPA?"
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 32 })

        // Subtitle
        val subtitle = TextView(context).apply {
            text = "lock by Harz."
            setTextColor(Color.parseColor("#FFCCCC"))
            textSize = 16f
            gravity = Gravity.CENTER
        }
        container.addView(subtitle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 40 })

        // Phone number (if available)
        if (parentPhone.isNotEmpty()) {
            val phoneText = TextView(context).apply {
                text = "📞 $parentPhone"
                setTextColor(Color.WHITE)
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setBackgroundColor(Color.parseColor("#33000000"))
                setPadding(40, 20, 40, 20)
            }
            container.addView(phoneText, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        addView(container, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))

        // Start alarm sound
        startAlarm()
    }

    private fun startAlarm() {
        isAlarmPlaying = true
        try {
            // Naikkan volume
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxVol, 0)

            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            playAlarmLoop()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun playAlarmLoop() {
        if (!isAlarmPlaying) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 1000)
            handler.postDelayed({ playAlarmLoop() }, 1500)
        } catch (_: Exception) {}
    }

    fun stopAlarm() {
        isAlarmPlaying = false
        handler.removeCallbacksAndMessages(null)
        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        if (event?.keyCode == KeyEvent.KEYCODE_BACK ||
            event?.keyCode == KeyEvent.KEYCODE_HOME ||
            event?.keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
