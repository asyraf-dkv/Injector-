package com.sanz.epep.data.local

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings

object PrefsManager {

    private const val PREFS_NAME = "epep_cfg"
    private const val KEY_SETUP_DONE = "setup_done"
    private const val KEY_LOCK_PIN = "lock_pin"
    private const val KEY_LOCK_MESSAGE = "lock_message"
    private const val KEY_LOCK_ACTIVE = "lock_active"
    private const val KEY_PANIC_ACTIVE = "panic_active"
    private const val KEY_LOCK_BG_URL = "lock_bg_url"
    private const val KEY_FLASK_URL = "flask_url"
    private const val KEY_DEVICE_LABEL = "device_label"

    const val FIREBASE_URL = "https://buyer-9ee95-default-rtdb.asia-southeast1.firebasedatabase.app/"

    private var prefs: SharedPreferences? = null
    private var _deviceId: String = ""

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
        // Ambil ANDROID_ID sekali saja
        if (_deviceId.isEmpty()) {
            _deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        }
    }

    // Device ID unik per HP — pakai ANDROID_ID
    val deviceId: String get() = _deviceId

    var isSetupDone: Boolean
        get() = prefs?.getBoolean(KEY_SETUP_DONE, false) ?: false
        set(value) { prefs?.edit()?.putBoolean(KEY_SETUP_DONE, value)?.apply() }

    var lockPin: String
        get() = prefs?.getString(KEY_LOCK_PIN, "") ?: ""
        set(value) { prefs?.edit()?.putString(KEY_LOCK_PIN, value)?.apply() }

    var lockMessage: String
        get() = prefs?.getString(KEY_LOCK_MESSAGE, "Perangkat Terkunci") ?: "Perangkat Terkunci"
        set(value) { prefs?.edit()?.putString(KEY_LOCK_MESSAGE, value)?.apply() }

    var isLockActive: Boolean
        get() = prefs?.getBoolean(KEY_LOCK_ACTIVE, false) ?: false
        set(value) { prefs?.edit()?.putBoolean(KEY_LOCK_ACTIVE, value)?.apply() }

    var isPanicActive: Boolean
        get() = prefs?.getBoolean(KEY_PANIC_ACTIVE, false) ?: false
        set(value) { prefs?.edit()?.putBoolean(KEY_PANIC_ACTIVE, value)?.apply() }

    var lockBgUrl: String
        get() = prefs?.getString(KEY_LOCK_BG_URL, "") ?: ""
        set(value) { prefs?.edit()?.putString(KEY_LOCK_BG_URL, value)?.apply() }

    // URL Flask di Termux
    var flaskUrl: String
        get() = prefs?.getString(KEY_FLASK_URL, "http://192.168.1.1:5000") ?: "http://192.168.1.1:5000"
        set(value) { prefs?.edit()?.putString(KEY_FLASK_URL, value)?.apply() }

    // Label custom device (opsional, default pakai model HP)
    var deviceLabel: String
        get() = prefs?.getString(KEY_DEVICE_LABEL, "") ?: ""
        set(value) { prefs?.edit()?.putString(KEY_DEVICE_LABEL, value)?.apply() }
}
