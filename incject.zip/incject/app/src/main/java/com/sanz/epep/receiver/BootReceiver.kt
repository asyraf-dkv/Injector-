package com.sanz.epep.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.sanz.epep.data.local.PrefsManager
import com.sanz.epep.overlay.OverlayManager
import com.sanz.epep.service.FirebaseListenerService

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val validActions = listOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON"
        )

        if (intent.action in validActions) {
            PrefsManager.init(context)
            if (PrefsManager.isSetupDone) {
                FirebaseListenerService.start(context)
                OverlayManager.restoreAfterBoot(context)
            }
        }
    }
}
