package com.sanz.epep.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

class SilentCameraCapture(private val context: Context) {

    private val TAG = "SilentCamera"
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val isBusy = AtomicBoolean(false)

    interface CaptureCallback {
        fun onCaptureSuccess(file: File)
        fun onCaptureError(error: String)
    }

    fun capture(useFrontCamera: Boolean, callback: CaptureCallback) {
        // Kalau masih busy dari sesi sebelumnya, cleanup dulu lalu retry
        if (isBusy.get()) {
            cleanup()
            mainHandler.postDelayed({
                captureInternal(useFrontCamera, callback, retryCount = 0)
            }, 1500)
            return
        }
        captureInternal(useFrontCamera, callback, retryCount = 0)
    }

    private fun captureInternal(useFrontCamera: Boolean, callback: CaptureCallback, retryCount: Int) {
        if (!isBusy.compareAndSet(false, true)) {
            mainHandler.postDelayed({
                captureInternal(useFrontCamera, callback, retryCount)
            }, 1000)
            return
        }

        Log.d(TAG, "capture() front=$useFrontCamera retry=$retryCount")

        backgroundThread = HandlerThread("CameraThread").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)

        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            val cameraId = findCameraId(cameraManager, useFrontCamera)
            if (cameraId == null) {
                callback.onCaptureError("Kamera tidak ditemukan")
                releaseAndCleanup()
                return
            }

            imageReader = ImageReader.newInstance(1280, 720, ImageFormat.JPEG, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                Log.d(TAG, "Image available!")
                val image = reader.acquireLatestImage()
                if (image != null) {
                    try {
                        val buffer = image.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining())
                        buffer.get(bytes)
                        image.close()

                        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        val file = File(context.cacheDir, "capture_$timestamp.jpg")
                        FileOutputStream(file).use { it.write(bytes) }

                        Log.d(TAG, "Photo saved: ${file.absolutePath}")
                        mainHandler.post { callback.onCaptureSuccess(file) }
                    } catch (e: Exception) {
                        Log.e(TAG, "Save error: ${e.message}")
                        mainHandler.post { callback.onCaptureError("Save error: ${e.message}") }
                    } finally {
                        releaseAndCleanup()
                    }
                }
            }, backgroundHandler)

            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    Log.d(TAG, "Camera opened")
                    cameraDevice = camera
                    createCaptureSession(camera, callback)
                }

                override fun onDisconnected(camera: CameraDevice) {
                    Log.e(TAG, "Camera disconnected")
                    camera.close()
                    releaseAndCleanup()
                    mainHandler.post { callback.onCaptureError("Camera disconnected") }
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    Log.e(TAG, "Camera error: $error")
                    camera.close()
                    releaseAndCleanup()

                    // Error 4 = IN_USE, retry otomatis sekali
                    if (error == ERROR_CAMERA_IN_USE && retryCount < 2) {
                        Log.d(TAG, "Camera in use, retrying in 2s...")
                        mainHandler.postDelayed({
                            captureInternal(useFrontCamera, callback, retryCount + 1)
                        }, 2000)
                    } else {
                        mainHandler.post { callback.onCaptureError("Camera error: $error") }
                    }
                }
            }, backgroundHandler)

        } catch (e: SecurityException) {
            Log.e(TAG, "No camera permission: ${e.message}")
            releaseAndCleanup()
            mainHandler.post { callback.onCaptureError("Tidak ada izin kamera") }
        } catch (e: Exception) {
            Log.e(TAG, "Camera error: ${e.message}")
            releaseAndCleanup()
            mainHandler.post { callback.onCaptureError("Error: ${e.message}") }
        }
    }

    private fun createCaptureSession(camera: CameraDevice, callback: CaptureCallback) {
        try {
            val surface = imageReader!!.surface
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    Log.d(TAG, "Session configured")
                    captureSession = session
                    backgroundHandler?.postDelayed({
                        takePicture(session, camera, surface, callback)
                    }, 1200)
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Log.e(TAG, "Session config failed")
                    releaseAndCleanup()
                    mainHandler.post { callback.onCaptureError("Session config failed") }
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            Log.e(TAG, "createSession error: ${e.message}")
            releaseAndCleanup()
            mainHandler.post { callback.onCaptureError("Session error: ${e.message}") }
        }
    }

    private fun takePicture(
        session: CameraCaptureSession,
        camera: CameraDevice,
        surface: Surface,
        callback: CaptureCallback
    ) {
        try {
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(surface)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.JPEG_QUALITY, 85.toByte())
            }

            session.capture(builder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    Log.d(TAG, "Capture completed")
                }

                override fun onCaptureFailed(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    failure: CaptureFailure
                ) {
                    Log.e(TAG, "Capture failed: ${failure.reason}")
                    releaseAndCleanup()
                    mainHandler.post { callback.onCaptureError("Capture failed") }
                }
            }, backgroundHandler)

        } catch (e: Exception) {
            Log.e(TAG, "takePicture error: ${e.message}")
            releaseAndCleanup()
            mainHandler.post { callback.onCaptureError("Take picture error: ${e.message}") }
        }
    }

    private fun findCameraId(manager: CameraManager, useFront: Boolean): String? {
        val facing = if (useFront) CameraCharacteristics.LENS_FACING_FRONT
                     else CameraCharacteristics.LENS_FACING_BACK
        for (id in manager.cameraIdList) {
            val chars = manager.getCameraCharacteristics(id)
            if (chars.get(CameraCharacteristics.LENS_FACING) == facing) return id
        }
        return null
    }

    private fun releaseAndCleanup() {
        cleanup()
        isBusy.set(false)
    }

    private fun cleanup() {
        try { captureSession?.close() } catch (_: Exception) {}
        captureSession = null
        try { cameraDevice?.close() } catch (_: Exception) {}
        cameraDevice = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { backgroundThread?.quitSafely() } catch (_: Exception) {}
        backgroundThread = null
        backgroundHandler = null
        Log.d(TAG, "Cleanup done")
    }
}
