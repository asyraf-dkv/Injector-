package com.sanz.epep.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MessageOverlayView(
    context: Context,
    private val message: String
) : FrameLayout(context) {

    init {
        setPadding(32, 16, 32, 16)

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 32)

            // Rounded background
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6222222"))
                cornerRadius = 32f
                setStroke(2, Color.parseColor("#444444"))
            }

            elevation = 16f
        }

        // Header
        val header = TextView(context).apply {
            text = "💬 Pesan dari Anonymous"
            setTextColor(Color.parseColor("#4FC3F7"))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(header, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 })

        // Message content
        val content = TextView(context).apply {
            text = message
            setTextColor(Color.WHITE)
            textSize = 17f
            maxLines = 5
        }
        card.addView(content, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        addView(card, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ))
    }
}
