# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# Keep app classes
-keep class com.sanz.epep.** { *; }
